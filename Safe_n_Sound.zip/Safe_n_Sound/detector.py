from threading import Thread
from PIL import Image
from matplotlib import pyplot as plt
import numpy as np
import face_recognition
import cv2
import sys
import os
import datetime
import time
from imutils.video import WebcamVideoStream
from imutils.video import FPS
import imutils
import argparse
import glob
import logging
from time import time
import pandas as pd

'''
ap = argparse.ArgumentParser()
ap.add_argument("-n", "--num-frames", type=int, default=100,
	help="# of frames to loop over for FPS test")
ap.add_argument("-d", "--display", type=int, default=-1,
	help="Whether or not frames should be displayed")
args = vars(ap.parse_args())'''

class FPS:
	def __init__(self):
		# store the start time, end time, and total number of frames
		# that were examined between the start and end intervals
		self._start = None
		self._end = None
		self._numFrames = 0

	def start(self):
		# start the timer
		self._start = datetime.datetime.now()
		return self

	def stop(self):
		# stop the timer
		self._end = datetime.datetime.now()

	def update(self):
		# increment the total number of frames examined during the
		# start and end intervals
		self._numFrames += 1

	def elapsed(self):
		# return the total number of seconds between the start and
		# end interval
		return (self._end - self._start).total_seconds()

	def fps(self):
		# compute the (approximate) frames per second
		return self._numFrames / self.elapsed()

class WebcamVideoStream:
    def __init__(self, src=0):
    	# initialize the video camera stream and read the first frame
    	# from the stream
    	self.stream = cv2.VideoCapture(src)
    	(self.grabbed, self.frame) = self.stream.read()

    	# initialize the variable used to indicate if the thread should
    	# be stopped
    	self.stopped = False

    def start(self):
    	# start the thread to read frames from the video stream
    	Thread(target=self.update, args=()).start()
    	return self

    def update(self):
    	# keep looping infinitely until the thread is stopped
    	while True:
    		# if the thread indicator variable is set, stop the thread
    		if self.stopped:
    			return

    		# otherwise, read the next frame from the stream
    		(self.grabbed, self.frame) = self.stream.read()

    def read(self):
    	# return the frame most recently read
    	return self.frame

    def stop(self):
    	# indicate that the thread should be stopped
    	self.stopped = True

# created a *threaded* video stream, allow the camera sensor to warmup,
# and start the FPS counter
print("[INFO] sampling THREADED frames from webcam...")
vs = WebcamVideoStream(src=0).start()
#fps = FPS().start()

face_cascade = cv2.CascadeClassifier('/Users/Palaksh 1/Library/Python/3.7/lib/python/site-packages/cv2/data/haarcascade_frontalface_default.xml')

face_counter = 51
img_counter = 0
max_counter = 0

dirpath = os.getcwd()

# loop over some frames...this time using the threaded stream
while max_counter < 5:
    # grab the frame from the threaded video stream and resize it
    # to have a maximum width of 400 pixels
    frame = vs.read()
    orig = frame.copy()
    frame = imutils.resize(frame, width=500)
    frame = cv2.flip(frame, 1)

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(
        gray,
        scaleFactor = 1.5,
        minNeighbors= 3,
        minSize=(50, 50),
        flags=cv2.CASCADE_SCALE_IMAGE
    )

    for (x,y,w,h) in faces:
        cv2.rectangle(frame,(x,y),(x+w,y+h),(255,0,0),2)
        roi_gray = gray[y:y+h, x:x+w]
        roi_color = frame[y:y+h, x:x+w]

    #if len(faces) == 0:
    #    face_counter += 1

    # check to see if the frame should be displayed to our screen
    #if args["display"] > 0:
    cv2.imshow("Safe n' Sound", frame)

    #if face_counter > 200:
    #    print("LOOK AT THE ROAD!")
    #    face_counter = 0

    if len(faces) != 0 and face_counter > 50:
        p = os.path.sep.join([dirpath + "/dataset", "{}.png".format(
        str(img_counter).zfill(5))])
        cv2.imwrite(p, orig)
        img_counter += 1
        max_counter += 1
        face_counter = 0

    face_counter += 1

    key = cv2.waitKey(1) & 0xFF

    if key == ord('q'):
        break
    # update the FPS counter
    #fps.update()

# stop the timer and display FPS information

# do a bit of cleanup
cv2.destroyAllWindows()
vs.stop()
