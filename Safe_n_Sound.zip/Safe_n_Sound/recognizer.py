from threading import Thread
from PIL import Image
from matplotlib import pyplot as plt
import numpy as np
import face_recognition
import cv2
import sys
import os
import datetime
import time
from imutils.video import WebcamVideoStream
from imutils.video import FPS
import imutils
import argparse
import glob
import logging
from time import time
import pandas as pd

class FPS:
	def __init__(self):
		# store the start time, end time, and total number of frames
		# that were examined between the start and end intervals
		self._start = None
		self._end = None
		self._numFrames = 0

	def start(self):
		# start the timer
		self._start = datetime.datetime.now()
		return self

	def stop(self):
		# stop the timer
		self._end = datetime.datetime.now()

	def update(self):
		# increment the total number of frames examined during the
		# start and end intervals
		self._numFrames += 1

	def elapsed(self):
		# return the total number of seconds between the start and
		# end interval
		return (self._end - self._start).total_seconds()

	def fps(self):
		# compute the (approximate) frames per second
		return self._numFrames / self.elapsed()

class WebcamVideoStream:
    def __init__(self, src=0):
    	# initialize the video camera stream and read the first frame
    	# from the stream
    	self.stream = cv2.VideoCapture(src)
    	(self.grabbed, self.frame) = self.stream.read()

    	# initialize the variable used to indicate if the thread should
    	# be stopped
    	self.stopped = False

    def start(self):
    	# start the thread to read frames from the video stream
    	Thread(target=self.update, args=()).start()
    	return self

    def update(self):
    	# keep looping infinitely until the thread is stopped
    	while True:
    		# if the thread indicator variable is set, stop the thread
    		if self.stopped:
    			return

    		# otherwise, read the next frame from the stream
    		(self.grabbed, self.frame) = self.stream.read()

    def read(self):
    	# return the frame most recently read
    	return self.frame

    def stop(self):
    	# indicate that the thread should be stopped
    	self.stopped = True

dirpath = os.getcwd()

IMAGES_PATH = (dirpath + "/dataset")  # put your reference images in here
CAMERA_DEVICE_ID = 0
MAX_DISTANCE = 0.5
face_counter = 0

def get_face_embeddings_from_image(image, convert_to_rgb=False):
    """
    Take a raw image and run both the face detection and face embedding model on it
    """

    global face_counter

    # Convert from BGR to RGB if needed
    if convert_to_rgb:
        image = image[:, :, ::-1]

    # run the face detection model to find face locations
    face_locations = face_recognition.face_locations(image)

    # run the embedding model to get face embeddings for the supplied locations
    face_encodings = face_recognition.face_encodings(image, face_locations)

    if len(face_encodings) == 0:
        face_counter += 1
    #else:
        #face_counter = 0

    return face_locations, face_encodings

def setup_database():
    """
    Load reference images and create a database of their face encodings
    """
    database = {}

    for filename in glob.glob(os.path.join(IMAGES_PATH, '*.png')):

        # load image
        image_rgb = face_recognition.load_image_file(filename)

        # use the name in the filename as the identity key
        identity = os.path.splitext(os.path.basename(filename))[0]

        # get the face encoding and link it to the identity
        locations, encodings = get_face_embeddings_from_image(image_rgb)
        database[identity] = encodings[0]

    return database

def paint_detected_face_on_image(frame, location, name=None):
    """
    Paint a rectangle around the face and write the name
    """
    # unpack the coordinates from the location tuple
    top, right, bottom, left = location
    global face_counter

    if name is None:
        name = 'Unknown'
        color = (0, 0, 255)
        # red for unrecognized face
    else:
        color = (0, 128, 0)  # dark green for recognized face
        face_counter = 0

    # Draw a box around the face
    cv2.rectangle(frame, (left, top), (right, bottom), color, 2)

    # Draw a label with a name below the face
    cv2.rectangle(frame, (left, bottom - 35), (right, bottom), color, cv2.FILLED)
    cv2.putText(frame, name, (left + 6, bottom - 6), cv2.FONT_HERSHEY_DUPLEX, 1.0, (255, 255, 255), 1)

def run_face_recognition(database):
    """
    Start the face recognition via the webcam
    """
    global face_counter

    # Open a handler for the camera
    video_capture = WebcamVideoStream(CAMERA_DEVICE_ID).start()

    # the face_recognitino library uses keys and values of your database separately
    known_face_encodings = list(database.values())
    known_face_names = list(database.keys())

    while video_capture.stream.isOpened():
        # Grab a single frame of video (and check if it went ok)
        frame = video_capture.read()
        frame = imutils.resize(frame, width=500)
        frame = cv2.flip(frame, 1)

        if not video_capture.grabbed:
            logging.error("Could not read frame from camera. Stopping video capture.")
            break

        # run detection and embedding models
        face_locations, face_encodings = get_face_embeddings_from_image(frame, convert_to_rgb=True)

        if face_counter > 40:
            print("LOOK AT THE ROAD!")
            face_counter = 0

        # Loop through each face in this frame of video and see if there's a match
        for location, face_encoding in zip(face_locations, face_encodings):

            # get the distances from this encoding to those of all reference images
            distances = face_recognition.face_distance(known_face_encodings, face_encoding)

            # select the closest match (smallest distance) if it's below the threshold value
            if np.any(distances <= 0.5):
                best_match_idx = np.argmin(distances)
                name = known_face_names[best_match_idx]
            else:
                name = None

            # put recognition info on the image
            paint_detected_face_on_image(frame, location, name)

        # Display the resulting image

        cv2.imshow('Video', frame)
        k = cv2.waitKey(1)

        orig = frame.copy()

        # Hit 'q' on the keyboard to quit!
        if k == ord('q'):
            break

    # Release handle to the webcam
    video_capture.stream.release()
    cv2.destroyAllWindows()

database = setup_database()
run_face_recognition(database)
